import { Router } from 'express';
import { createContactMessage, getAllContactMessages } from '../controllers/contact.controller';
import { validate } from '../middleware/validate';
import { createContactSchema } from '../validations/contact.validation';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.post('/', validate(createContactSchema), createContactMessage);
router.get('/', authenticate, authorize('ADMIN', 'SUPER_ADMIN'), getAllContactMessages);

export default router;
