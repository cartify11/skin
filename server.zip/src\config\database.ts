import { PrismaClient } from '@prisma/client';
import { env } from './env';
import { logger } from '../utils/logger';

export const prisma = new PrismaClient({
  log: env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
});

export const connectDatabase = async (): Promise<void> => {
  try {
    await prisma.$connect();
    logger.info('✅ PostgreSQL database connected via Prisma ORM.');
  } catch (error: any) {
    logger.warn(`⚠️ PostgreSQL connection warning: ${error.message || 'Can\'t reach database at localhost:5432'}`);
    logger.warn('ℹ️ Express server will run in fallback mode. Ensure PostgreSQL is active on port 5432 for live database operations.');
  }
};
