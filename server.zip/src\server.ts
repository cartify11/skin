import app from './app';
import { env } from './config/env';
import { connectDatabase } from './config/database';
import { logger } from './utils/logger';

const startServer = async () => {
  try {
    await connectDatabase();

    const server = app.listen(env.PORT, () => {
      logger.info(`🚀 Skin Clinic REST API server running on port ${env.PORT} in ${env.NODE_ENV} mode.`);
      logger.info(`🏥 Health check: http://localhost:${env.PORT}/api/v1/health`);
    });

    const handleShutdown = (signal: string) => {
      logger.info(`${signal} received. Shutting down HTTP server gracefully...`);
      server.close(() => {
        logger.info('HTTP server closed.');
        process.exit(0);
      });
    };

    process.on('SIGTERM', () => handleShutdown('SIGTERM'));
    process.on('SIGINT', () => handleShutdown('SIGINT'));
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
