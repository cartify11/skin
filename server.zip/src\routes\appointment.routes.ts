import { Router } from 'express';
import { createAppointment, getAllAppointments, updateAppointmentStatus } from '../controllers/appointment.controller';
import { validate } from '../middleware/validate';
import { createAppointmentSchema, updateAppointmentStatusSchema } from '../validations/appointment.validation';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.post('/', validate(createAppointmentSchema), createAppointment);
router.get('/', authenticate, authorize('ADMIN', 'SUPER_ADMIN', 'DOCTOR'), getAllAppointments);
router.patch('/:id/status', authenticate, authorize('ADMIN', 'SUPER_ADMIN', 'DOCTOR'), validate(updateAppointmentStatusSchema), updateAppointmentStatus);

export default router;
