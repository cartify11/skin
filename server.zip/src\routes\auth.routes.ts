import { Router } from 'express';
import { login, registerAdmin } from '../controllers/auth.controller';
import { validate } from '../middleware/validate';
import { loginSchema, registerAdminSchema } from '../validations/auth.validation';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.post('/login', validate(loginSchema), login);
router.post('/register', authenticate, authorize('SUPER_ADMIN'), validate(registerAdminSchema), registerAdmin);

export default router;
