import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { sendResponse } from '../utils/apiResponse';
import { AppError } from '../utils/appError';

export const getAllDoctors = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const doctors = await prisma.doctor.findMany({
      orderBy: { createdAt: 'asc' },
    });
    sendResponse(res, 200, 'Doctors list fetched.', doctors);
  } catch (error) {
    next(error);
  }
};

export const getDoctorById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const doctor = await prisma.doctor.findUnique({ where: { id: req.params.id } });
    if (!doctor) return next(new AppError('Doctor not found.', 404));
    sendResponse(res, 200, 'Doctor details fetched.', doctor);
  } catch (error) {
    next(error);
  }
};

export const createDoctor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const doctor = await prisma.doctor.create({ data: req.body });
    sendResponse(res, 201, 'Doctor profile created.', doctor);
  } catch (error) {
    next(error);
  }
};
