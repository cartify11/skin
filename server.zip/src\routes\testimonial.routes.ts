import { Router } from 'express';
import { getAllTestimonials, createTestimonial } from '../controllers/testimonial.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.get('/', getAllTestimonials);
router.post('/', authenticate, authorize('ADMIN', 'SUPER_ADMIN'), createTestimonial);

export default router;
