import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { sendResponse } from '../utils/apiResponse';

export const getAllGalleryItems = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const gallery = await prisma.gallery.findMany({ orderBy: { createdAt: 'desc' } });
    sendResponse(res, 200, 'Gallery items fetched.', gallery);
  } catch (error) {
    next(error);
  }
};

export const createGalleryItem = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const galleryItem = await prisma.gallery.create({ data: req.body });
    sendResponse(res, 201, 'Gallery item created.', galleryItem);
  } catch (error) {
    next(error);
  }
};
