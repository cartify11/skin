import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { sendResponse } from '../utils/apiResponse';

export const createContactMessage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const contact = await prisma.contactMessage.create({ data: req.body });
    sendResponse(res, 201, 'Contact message sent successfully.', contact);
  } catch (error) {
    next(error);
  }
};

export const getAllContactMessages = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const messages = await prisma.contactMessage.findMany({ orderBy: { createdAt: 'desc' } });
    sendResponse(res, 200, 'Contact messages fetched.', messages);
  } catch (error) {
    next(error);
  }
};
