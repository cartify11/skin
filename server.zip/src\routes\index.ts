import { Router, Request, Response } from 'express';
import authRoutes from './auth.routes';
import doctorRoutes from './doctor.routes';
import serviceRoutes from './service.routes';
import appointmentRoutes from './appointment.routes';
import testimonialRoutes from './testimonial.routes';
import galleryRoutes from './gallery.routes';
import contactRoutes from './contact.routes';

const router = Router();

// Health Check Endpoint
router.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'success',
    message: 'Aura Skin Clinic API v1 is healthy and operational.',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// API v1 Sub-Routers
router.use('/auth', authRoutes);
router.use('/doctors', doctorRoutes);
router.use('/services', serviceRoutes);
router.use('/appointments', appointmentRoutes);
router.use('/testimonials', testimonialRoutes);
router.use('/gallery', galleryRoutes);
router.use('/contacts', contactRoutes);

export default router;
