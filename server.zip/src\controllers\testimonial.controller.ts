import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { sendResponse } from '../utils/apiResponse';

export const getAllTestimonials = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const testimonials = await prisma.testimonial.findMany({ orderBy: { createdAt: 'desc' } });
    sendResponse(res, 200, 'Testimonials fetched.', testimonials);
  } catch (error) {
    next(error);
  }
};

export const createTestimonial = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const testimonial = await prisma.testimonial.create({ data: req.body });
    sendResponse(res, 201, 'Testimonial created.', testimonial);
  } catch (error) {
    next(error);
  }
};
