import express, { Application, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'path';
import { env } from './config/env';
import v1Router from './routes/index';
import { errorHandler } from './middleware/errorHandler';
import { AppError } from './utils/appError';

const app: Application = express();

// Security Headers
app.use(helmet());

// CORS Configuration
app.use(
  cors({
    origin: env.CORS_ORIGIN,
    credentials: true,
  })
);

// Rate Limiting (100 requests per 15 minutes per IP)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: {
    success: false,
    message: 'Too many requests from this IP address, please try again after 15 minutes.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api', limiter);

// Request Parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static File Serving for Uploaded Assets
app.use('/uploads', express.static(path.join(__dirname, '../', env.UPLOAD_PATH)));

// API Versioning (/api/v1)
app.use('/api/v1', v1Router);

// 404 Route Not Found Handler
app.all('*', (req: Request, _res: Response, next: NextFunction) => {
  next(new AppError(`Cannot find route ${req.originalUrl} on this server.`, 404));
});

// Global Error Handler Middleware
app.use(errorHandler);

export default app;
