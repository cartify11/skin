module.exports = {
  apps: [
    {
      name: 'aura-skin-clinic-api',
      script: './dist/server.js',
      instances: 'max',
      exec_mode: 'cluster',
      env_production: {
        NODE_ENV: 'production',
        PORT: 5000,
      },
      max_memory_restart: '500M',
      restart_delay: 3000,
    },
  ],
};
