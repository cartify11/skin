import { z } from 'zod';

export const createAppointmentSchema = z.object({
  body: z.object({
    patientName: z.string().min(2, 'Patient name is required'),
    patientPhone: z.string().min(8, 'Valid phone number is required'),
    patientEmail: z.string().email('Invalid email address'),
    serviceId: z.string().uuid('Valid service ID required'),
    doctorId: z.string().uuid().optional(),
    appointmentDate: z.string().datetime({ offset: true }).or(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)),
    appointmentTime: z.string().min(2, 'Appointment time required'),
    isFirstVisit: z.boolean().optional(),
    notes: z.string().optional(),
  }),
});

export const updateAppointmentStatusSchema = z.object({
  params: z.object({
    id: z.string().uuid('Valid appointment ID required'),
  }),
  body: z.object({
    status: z.enum(['PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED']),
  }),
});
