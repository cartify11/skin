import { Router } from 'express';
import { getAllServices, getServiceBySlug, createService } from '../controllers/service.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.get('/', getAllServices);
router.get('/:slug', getServiceBySlug);
router.post('/', authenticate, authorize('ADMIN', 'SUPER_ADMIN'), createService);

export default router;
