import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { sendResponse } from '../utils/apiResponse';
import { AppError } from '../utils/appError';

export const getAllServices = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const services = await prisma.service.findMany({ orderBy: { title: 'asc' } });
    sendResponse(res, 200, 'Services list fetched.', services);
  } catch (error) {
    next(error);
  }
};

export const getServiceBySlug = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const service = await prisma.service.findUnique({ where: { slug: req.params.slug } });
    if (!service) return next(new AppError('Service not found.', 404));
    sendResponse(res, 200, 'Service details fetched.', service);
  } catch (error) {
    next(error);
  }
};

export const createService = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const service = await prisma.service.create({ data: req.body });
    sendResponse(res, 201, 'Service created.', service);
  } catch (error) {
    next(error);
  }
};
