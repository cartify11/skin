import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { sendResponse } from '../utils/apiResponse';
import { AppError } from '../utils/appError';

export const createAppointment = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const {
      patientName,
      patientPhone,
      patientEmail,
      serviceId,
      doctorId,
      appointmentDate,
      appointmentTime,
      isFirstVisit,
      notes,
    } = req.body;

    const referenceId = 'AUR-' + Math.floor(100000 + Math.random() * 900000);

    const appointment = await prisma.appointment.create({
      data: {
        referenceId,
        patientName,
        patientPhone,
        patientEmail,
        serviceId,
        doctorId: doctorId || null,
        appointmentDate: new Date(appointmentDate),
        appointmentTime,
        isFirstVisit: isFirstVisit ?? true,
        notes: notes || '',
        status: 'PENDING',
      },
      include: {
        service: true,
        doctor: true,
      },
    });

    sendResponse(res, 201, 'Appointment booked successfully.', appointment);
  } catch (error) {
    next(error);
  }
};

export const getAllAppointments = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const appointments = await prisma.appointment.findMany({
      include: {
        service: true,
        doctor: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    sendResponse(res, 200, 'Appointments retrieved successfully.', appointments);
  } catch (error) {
    next(error);
  }
};

export const updateAppointmentStatus = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const existing = await prisma.appointment.findUnique({ where: { id } });
    if (!existing) {
      return next(new AppError('Appointment not found.', 404));
    }

    const updated = await prisma.appointment.update({
      where: { id },
      data: { status },
    });

    sendResponse(res, 200, 'Appointment status updated.', updated);
  } catch (error) {
    next(error);
  }
};
