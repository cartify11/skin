import { z } from 'zod';

export const createDoctorSchema = z.object({
  body: z.object({
    name: z.string().min(2, 'Doctor name is required'),
    title: z.string().min(2, 'Title is required'),
    degrees: z.array(z.string()).min(1, 'At least one degree is required'),
    experienceYears: z.number().int().min(0),
    specialties: z.array(z.string()).min(1, 'At least one specialty is required'),
    bio: z.string().min(10, 'Bio must be at least 10 characters'),
    avatarUrl: z.string().url().optional(),
    rating: z.number().min(1).max(5).optional(),
    isAvailable: z.boolean().optional(),
  }),
});
