import { Router } from 'express';
import { getAllGalleryItems, createGalleryItem } from '../controllers/gallery.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.get('/', getAllGalleryItems);
router.post('/', authenticate, authorize('ADMIN', 'SUPER_ADMIN'), createGalleryItem);

export default router;
