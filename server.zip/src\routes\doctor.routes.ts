import { Router } from 'express';
import { getAllDoctors, getDoctorById, createDoctor } from '../controllers/doctor.controller';
import { validate } from '../middleware/validate';
import { createDoctorSchema } from '../validations/doctor.validation';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.get('/', getAllDoctors);
router.get('/:id', getDoctorById);
router.post('/', authenticate, authorize('ADMIN', 'SUPER_ADMIN'), validate(createDoctorSchema), createDoctor);

export default router;
